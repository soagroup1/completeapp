/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.model;

/**
 *
 * @author Pradeep
 */
public class employees {
    
    private String employeeid;
    private String firstname;
    private String lastname;
    private String email;
    private int extension;
    private int homephone;
    private int cellphone;
    private String job_title;
    private int ssn;
    private String dlnumber;
    private String address;
    private String city;
    private String state;
    private int postalcode;
    private String birthdate;
    private String datehired;
    private double salary;
    private String notes;

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setExtension(int extension) {
        this.extension = extension;
    }

    public void setHomephone(int homephone) {
        this.homephone = homephone;
    }

    public void setCellphone(int cellphone) {
        this.cellphone = cellphone;
    }

    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }

    public void setSsn(int ssn) {
        this.ssn = ssn;
    }

    public void setDlnumber(String dlnumber) {
        this.dlnumber = dlnumber;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setPostalcode(int postalcode) {
        this.postalcode = postalcode;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public void setDatehired(String datehired) {
        this.datehired = datehired;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getEmail() {
        return email;
    }

    public int getExtension() {
        return extension;
    }

    public int getHomephone() {
        return homephone;
    }

    public int getCellphone() {
        return cellphone;
    }

    public String getJob_title() {
        return job_title;
    }

    public int getSsn() {
        return ssn;
    }

    public String getDlnumber() {
        return dlnumber;
    }

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public int getPostalcode() {
        return postalcode;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public String getDatehired() {
        return datehired;
    }

    public double getSalary() {
        return salary;
    }

    public String getNotes() {
        return notes;
    }
          
}

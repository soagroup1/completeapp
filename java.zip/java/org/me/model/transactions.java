/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.model;

/**
 *
 * @author Pradeep
 */
public class transactions {
    private String transactionID;
    private String transactionDate;
    private String transactionDescription;
    private String transactionAmount;
    private String make;
    private String model;
    private String year;
    private String VIN;
    private String runNumber;
    private String quantity;
    private String discount;
    private String unitPrice;
    private String rate;
    private String surcharge;
    private String setpriceID;
    private Long employeeID;
    private Long truckid;
    private String truckNo;
    private String driverPrice;
    private String special;

    public void setSpecial(String special) {
        this.special = special;
    }

    public String getSpecial() {
        return special;
    }
    private String sptransaction_Amountecial;

    public String getTransactionID() {
        return transactionID;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public String getTransactionDescription() {
        return transactionDescription;
    }

    public String getTransactionAmount() {
        return transactionAmount;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String getYear() {
        return year;
    }

    public String getVIN() {
        return VIN;
    }

    public String getRunNumber() {
        return runNumber;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getDiscount() {
        return discount;
    }

    public String getUnitPrice() {
        return unitPrice;
    }

    public String getRate() {
        return rate;
    }

    public String getSurcharge() {
        return surcharge;
    }

    public String getSetpriceID() {
        return setpriceID;
    }

    public Long getEmployeeID() {
        return employeeID;
    }

    public Long getTruckid() {
        return truckid;
    }

    public String getTruckNo() {
        return truckNo;
    }

    public String getDriverPrice() {
        return driverPrice;
    }

    public String getSptransaction_Amountecial() {
        return sptransaction_Amountecial;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public void setTransactionDescription(String transactionDescription) {
        this.transactionDescription = transactionDescription;
    }

    public void setTransactionAmount(String transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public void setVIN(String VIN) {
        this.VIN = VIN;
    }

    public void setRunNumber(String runNumber) {
        this.runNumber = runNumber;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public void setUnitPrice(String unitPrice) {
        this.unitPrice = unitPrice;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public void setSurcharge(String surcharge) {
        this.surcharge = surcharge;
    }

    public void setSetpriceID(String setpriceID) {
        this.setpriceID = setpriceID;
    }

    public void setEmployeeID(Long employeeID) {
        this.employeeID = employeeID;
    }

    public void setTruckid(Long truckid) {
        this.truckid = truckid;
    }

    public void setTruckNo(String truckNo) {
        this.truckNo = truckNo;
    }

    public void setDriverPrice(String driverPrice) {
        this.driverPrice = driverPrice;
    }

    public void setSptransaction_Amountecial(String sptransaction_Amountecial) {
        this.sptransaction_Amountecial = sptransaction_Amountecial;
    }

  

    

    
    
}
